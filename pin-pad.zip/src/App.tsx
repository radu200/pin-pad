import PagePinPad from './pages';

function App() {
  return <PagePinPad />;
}

export default App;
